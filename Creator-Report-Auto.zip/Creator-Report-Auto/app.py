import streamlit as st
import pandas as pd
import random
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
from datetime import datetime

POSITIONS = ["GK", "DFC", "DFC", "DFC", "DFC", "MC", "MC", "MC", "MC", "ST", "ST"]
POSITION_DISTRIBUTION = {"GK": 3, "DFC": 6, "MC": 8, "ST": 6}

FIRST_NAMES = [
    "James", "John", "Robert", "Michael", "David", "William", "Richard", "Joseph", "Thomas", "Christopher",
    "Carlos", "Miguel", "Luis", "Diego", "Pedro", "Marco", "Luca", "Giovanni", "Francesco", "Alessandro",
    "Jean", "Pierre", "Antoine", "Lucas", "Hugo", "Mohammed", "Ahmed", "Omar", "Youssef", "Ali",
    "Kai", "Leon", "Finn", "Noah", "Liam", "Oscar", "Erik", "Stefan", "Viktor", "Andrei",
    "Paulo", "Rafael", "Bruno", "Thiago", "Gabriel", "Kenji", "Hiroshi", "Yuki", "Taro", "Ryu"
]

LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez",
    "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Silva", "Santos", "Costa", "Oliveira", "Ferreira",
    "Mueller", "Schmidt", "Schneider", "Fischer", "Weber", "Rossi", "Russo", "Ferrari", "Romano", "Colombo",
    "Dubois", "Martin", "Bernard", "Thomas", "Robert", "Yamamoto", "Tanaka", "Watanabe", "Suzuki", "Takahashi",
    "Petrov", "Ivanov", "Popov", "Johansson", "Eriksson", "Nielsen", "Hansen", "Larsen", "Berg", "Lindberg"
]

TEAM_NAMES = {
    1: ["Manchester City", "Liverpool", "Chelsea", "Arsenal", "Tottenham", "Manchester United", "Newcastle", "Brighton"],
    2: ["Leeds United", "West Ham", "Leicester City", "Everton", "Wolves", "Crystal Palace", "Aston Villa", "Fulham"],
    3: ["Southampton", "Burnley", "Watford", "Norwich", "Sheffield United", "Middlesbrough", "Sunderland", "Stoke City"],
    4: ["Blackburn", "Bolton", "Charlton", "Derby County", "Nottingham Forest", "Reading", "Birmingham", "Wigan"]
}

DIVISION_NAMES = {1: "Premier League", 2: "Championship", 3: "League One", 4: "League Two"}

COMMENTARY_TEMPLATES = {
    "goal": [
        "{scorer} scores for {team}! {assister} with the assist.",
        "GOAL! {scorer} finds the net for {team}. Set up by {assister}.",
        "What a strike from {scorer}! {team} celebrate as {assister} gets the assist.",
        "{scorer} doesn't miss from there! {assister} with a perfect pass for {team}.",
        "Clinical finish by {scorer} for {team}! {assister} provided the opportunity."
    ],
    "goal_no_assist": [
        "{scorer} goes it alone and scores for {team}!",
        "Brilliant solo goal by {scorer}! {team} take the lead.",
        "{scorer} with a moment of magic for {team}!",
        "What a goal! {scorer} does it all himself for {team}!",
        "{scorer} picks up the loose ball and finishes beautifully for {team}!"
    ],
    "match_start": [
        "The referee blows the whistle! {home} vs {away} is underway!",
        "And we're off! {home} taking on {away} today.",
        "The match begins between {home} and {away}!"
    ],
    "match_end": [
        "Full time! {home} {home_score} - {away_score} {away}",
        "The referee blows for full time. Final score: {home} {home_score} - {away_score} {away}",
        "That's the end of the match! {home} {home_score} - {away_score} {away}"
    ],
    "injury": [
        "{player} goes down injured! {team} will be without him for {weeks} weeks.",
        "Bad news for {team} - {player} has picked up an injury. Out for {weeks} weeks.",
        "Injury concern for {team} as {player} limps off. Expected to miss {weeks} weeks."
    ]
}

@dataclass
class Player:
    name: str
    position: str
    rating: int
    team: str
    age: int = 25
    goals: int = 0
    assists: int = 0
    form: int = 70
    fitness: int = 100
    injured_weeks: int = 0
    base_rating: int = 0
    market_value: int = 0
    
    def __post_init__(self):
        if self.base_rating == 0:
            self.base_rating = self.rating
        if self.market_value == 0:
            self.market_value = self.calculate_market_value()
    
    def calculate_market_value(self) -> int:
        base_value = self.rating * 100000
        age_factor = 1.0
        if self.age < 23:
            age_factor = 1.5
        elif self.age < 27:
            age_factor = 1.3
        elif self.age < 30:
            age_factor = 1.0
        elif self.age < 33:
            age_factor = 0.6
        else:
            age_factor = 0.3
        return int(base_value * age_factor)
    
    def get_effective_rating(self) -> int:
        form_modifier = (self.form - 70) / 50
        fitness_modifier = (self.fitness - 70) / 100
        effective = self.rating + (form_modifier * 10) + (fitness_modifier * 5)
        return max(40, min(99, int(effective)))
    
    def is_available(self) -> bool:
        return self.injured_weeks == 0 and self.fitness > 30
    
    def to_dict(self):
        return {
            "name": self.name,
            "position": self.position,
            "rating": self.rating,
            "team": self.team,
            "age": self.age,
            "goals": self.goals,
            "assists": self.assists,
            "form": self.form,
            "fitness": self.fitness,
            "injured_weeks": self.injured_weeks,
            "base_rating": self.base_rating,
            "market_value": self.market_value
        }
    
    @classmethod
    def from_dict(cls, data):
        return cls(**data)

@dataclass
class Team:
    name: str
    division: int
    rating: int
    players: List[Player] = field(default_factory=list)
    budget: int = 10000000
    
    def get_available_players(self) -> List[Player]:
        return [p for p in self.players if p.is_available()]
    
    def get_team_strength(self) -> int:
        available = self.get_available_players()
        if not available:
            return self.rating - 20
        avg_effective = sum(p.get_effective_rating() for p in available) / len(available)
        return int(avg_effective)
    
    def to_dict(self):
        return {
            "name": self.name,
            "division": self.division,
            "rating": self.rating,
            "players": [p.to_dict() for p in self.players],
            "budget": self.budget
        }
    
    @classmethod
    def from_dict(cls, data):
        players = [Player.from_dict(p) for p in data.get("players", [])]
        return cls(name=data["name"], division=data["division"], rating=data["rating"], 
                   players=players, budget=data.get("budget", 10000000))

@dataclass
class Match:
    home_team: str
    away_team: str
    home_goals: int = 0
    away_goals: int = 0
    played: bool = False
    goal_scorers: List[Tuple[str, str]] = field(default_factory=list)
    assisters: List[Tuple[str, str]] = field(default_factory=list)
    commentary: List[str] = field(default_factory=list)
    injuries: List[Tuple[str, str, int]] = field(default_factory=list)
    
    def to_dict(self):
        return {
            "home_team": self.home_team,
            "away_team": self.away_team,
            "home_goals": self.home_goals,
            "away_goals": self.away_goals,
            "played": self.played,
            "goal_scorers": self.goal_scorers,
            "assisters": self.assisters,
            "commentary": self.commentary,
            "injuries": self.injuries
        }
    
    @classmethod
    def from_dict(cls, data):
        return cls(**data)

@dataclass
class SeasonHistory:
    season_number: int
    division_winners: Dict[int, str] = field(default_factory=dict)
    top_scorers: List[Dict] = field(default_factory=list)
    top_assisters: List[Dict] = field(default_factory=list)
    promotions: Dict[int, List[str]] = field(default_factory=dict)
    relegations: Dict[int, List[str]] = field(default_factory=dict)
    cup_winner: str = ""
    
    def to_dict(self):
        return {
            "season_number": self.season_number,
            "division_winners": self.division_winners,
            "top_scorers": self.top_scorers,
            "top_assisters": self.top_assisters,
            "promotions": self.promotions,
            "relegations": self.relegations,
            "cup_winner": self.cup_winner
        }
    
    @classmethod
    def from_dict(cls, data):
        return cls(**data)

@dataclass
class CupMatch:
    home_team: str
    away_team: str
    home_goals: int = 0
    away_goals: int = 0
    played: bool = False
    round_name: str = ""
    winner: str = ""
    commentary: List[str] = field(default_factory=list)
    
    def to_dict(self):
        return {
            "home_team": self.home_team,
            "away_team": self.away_team,
            "home_goals": self.home_goals,
            "away_goals": self.away_goals,
            "played": self.played,
            "round_name": self.round_name,
            "winner": self.winner,
            "commentary": self.commentary
        }
    
    @classmethod
    def from_dict(cls, data):
        return cls(**data)

@dataclass
class TransferListing:
    player_name: str
    selling_team: str
    asking_price: int
    player_data: Dict = field(default_factory=dict)
    
    def to_dict(self):
        return {
            "player_name": self.player_name,
            "selling_team": self.selling_team,
            "asking_price": self.asking_price,
            "player_data": self.player_data
        }
    
    @classmethod
    def from_dict(cls, data):
        return cls(**data)

def generate_player_name():
    return f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"

def generate_player_age():
    weights = [1, 2, 3, 4, 5, 5, 5, 5, 4, 4, 3, 3, 2, 2, 1, 1, 1]
    ages = list(range(17, 34))
    return random.choices(ages, weights=weights)[0]

def generate_players_for_team(team_name: str, team_rating: int) -> List[Player]:
    players = []
    squad_size = random.randint(22, 25)
    
    positions_needed = []
    for pos, count in POSITION_DISTRIBUTION.items():
        positions_needed.extend([pos] * count)
    
    while len(positions_needed) < squad_size:
        positions_needed.append(random.choice(["DFC", "MC", "ST"]))
    
    positions_needed = positions_needed[:squad_size]
    random.shuffle(positions_needed)
    
    for position in positions_needed:
        rating_variation = random.randint(-15, 15)
        player_rating = max(40, min(99, team_rating + rating_variation))
        age = generate_player_age()
        
        player = Player(
            name=generate_player_name(),
            position=position,
            rating=player_rating,
            team=team_name,
            age=age,
            form=random.randint(60, 80),
            fitness=random.randint(85, 100)
        )
        players.append(player)
    
    return players

def create_league() -> Dict[int, List[Team]]:
    league = {}
    
    for division in range(1, 5):
        teams = []
        base_rating = 88 - (division - 1) * 7
        base_budget = 50000000 - (division - 1) * 10000000
        
        for team_name in TEAM_NAMES[division]:
            team_rating = base_rating + random.randint(-5, 5)
            team_rating = max(60, min(99, team_rating))
            team = Team(name=team_name, division=division, rating=team_rating, 
                       budget=base_budget + random.randint(-5000000, 5000000))
            team.players = generate_players_for_team(team_name, team_rating)
            teams.append(team)
        
        league[division] = teams
    
    return league

def generate_fixtures(teams: List[Team]) -> List[List[Match]]:
    team_names = [t.name for t in teams]
    n = len(team_names)
    
    if n % 2 == 1:
        team_names.append("BYE")
        n += 1
    
    fixtures = []
    
    for round_num in range(n - 1):
        round_matches = []
        for i in range(n // 2):
            home = team_names[i]
            away = team_names[n - 1 - i]
            if home != "BYE" and away != "BYE":
                round_matches.append(Match(home_team=home, away_team=away))
        fixtures.append(round_matches)
        
        team_names = [team_names[0]] + [team_names[-1]] + team_names[1:-1]
    
    second_half = []
    for round_matches in fixtures:
        reverse_round = []
        for match in round_matches:
            reverse_round.append(Match(home_team=match.away_team, away_team=match.home_team))
        second_half.append(reverse_round)
    
    fixtures.extend(second_half)
    
    return fixtures

def generate_cup_draw(league: Dict[int, List[Team]]) -> List[CupMatch]:
    all_teams = []
    for div_teams in league.values():
        all_teams.extend([t.name for t in div_teams])
    
    random.shuffle(all_teams)
    
    matches = []
    for i in range(0, len(all_teams), 2):
        if i + 1 < len(all_teams):
            matches.append(CupMatch(
                home_team=all_teams[i],
                away_team=all_teams[i + 1],
                round_name="Round 1"
            ))
    
    return matches

def simulate_cup_match(match: CupMatch, teams: Dict[str, Team]) -> CupMatch:
    home_team = teams[match.home_team]
    away_team = teams[match.away_team]
    
    home_strength = home_team.get_team_strength() + 3
    away_strength = away_team.get_team_strength()
    
    total_strength = home_strength + away_strength
    home_prob = home_strength / total_strength
    
    home_expected = 1.2 + (home_prob - 0.5) * 2
    away_expected = 1.2 + (0.5 - home_prob + 0.5) * 2 - 0.5
    
    home_goals = max(0, int(random.gauss(home_expected, 1.3)))
    away_goals = max(0, int(random.gauss(away_expected, 1.3)))
    
    home_goals = min(home_goals, 6)
    away_goals = min(away_goals, 6)
    
    if home_goals == away_goals:
        if random.random() < home_prob:
            home_goals += 1
        else:
            away_goals += 1
    
    match.home_goals = home_goals
    match.away_goals = away_goals
    match.played = True
    match.winner = match.home_team if home_goals > away_goals else match.away_team
    
    match.commentary = [
        random.choice(COMMENTARY_TEMPLATES["match_start"]).format(home=match.home_team, away=match.away_team),
        f"Cup match intensity as both teams fight for a spot in the next round!",
        random.choice(COMMENTARY_TEMPLATES["match_end"]).format(
            home=match.home_team, away=match.away_team,
            home_score=home_goals, away_score=away_goals
        ),
        f"{match.winner} advances to the next round!"
    ]
    
    return match

def simulate_match(match: Match, teams: Dict[str, Team]) -> Match:
    home_team = teams[match.home_team]
    away_team = teams[match.away_team]
    
    home_strength = home_team.get_team_strength() + 5
    away_strength = away_team.get_team_strength()
    
    total_strength = home_strength + away_strength
    home_prob = home_strength / total_strength
    
    home_expected = 1.3 + (home_prob - 0.5) * 2
    away_expected = 1.3 + (0.5 - home_prob + 0.5) * 2 - 0.5
    
    home_goals = max(0, int(random.gauss(home_expected, 1.2)))
    away_goals = max(0, int(random.gauss(away_expected, 1.2)))
    
    home_goals = min(home_goals, 7)
    away_goals = min(away_goals, 7)
    
    match.home_goals = home_goals
    match.away_goals = away_goals
    match.played = True
    match.goal_scorers = []
    match.assisters = []
    match.commentary = []
    match.injuries = []
    
    match.commentary.append(
        random.choice(COMMENTARY_TEMPLATES["match_start"]).format(
            home=home_team.name, away=away_team.name
        )
    )
    
    home_available = home_team.get_available_players()
    away_available = away_team.get_available_players()
    
    home_scorers = [p for p in home_available if p.position in ["ST", "MC"]]
    away_scorers = [p for p in away_available if p.position in ["ST", "MC"]]
    
    all_goal_events = []
    
    for _ in range(home_goals):
        if home_scorers:
            weights = [p.get_effective_rating() for p in home_scorers]
            scorer = random.choices(home_scorers, weights=weights)[0]
            scorer.goals += 1
            scorer.form = min(99, scorer.form + 3)
            match.goal_scorers.append((scorer.name, home_team.name))
            
            assister_name = None
            if random.random() < 0.7:
                possible_assisters = [p for p in home_available if p != scorer]
                if possible_assisters:
                    weights = [p.get_effective_rating() for p in possible_assisters]
                    assister = random.choices(possible_assisters, weights=weights)[0]
                    assister.assists += 1
                    assister.form = min(99, assister.form + 2)
                    match.assisters.append((assister.name, home_team.name))
                    assister_name = assister.name
            
            if assister_name:
                comment = random.choice(COMMENTARY_TEMPLATES["goal"]).format(
                    scorer=scorer.name, team=home_team.name, assister=assister_name
                )
            else:
                comment = random.choice(COMMENTARY_TEMPLATES["goal_no_assist"]).format(
                    scorer=scorer.name, team=home_team.name
                )
            all_goal_events.append(("home", comment))
    
    for _ in range(away_goals):
        if away_scorers:
            weights = [p.get_effective_rating() for p in away_scorers]
            scorer = random.choices(away_scorers, weights=weights)[0]
            scorer.goals += 1
            scorer.form = min(99, scorer.form + 3)
            match.goal_scorers.append((scorer.name, away_team.name))
            
            assister_name = None
            if random.random() < 0.7:
                possible_assisters = [p for p in away_available if p != scorer]
                if possible_assisters:
                    weights = [p.get_effective_rating() for p in possible_assisters]
                    assister = random.choices(possible_assisters, weights=weights)[0]
                    assister.assists += 1
                    assister.form = min(99, assister.form + 2)
                    match.assisters.append((assister.name, away_team.name))
                    assister_name = assister.name
            
            if assister_name:
                comment = random.choice(COMMENTARY_TEMPLATES["goal"]).format(
                    scorer=scorer.name, team=away_team.name, assister=assister_name
                )
            else:
                comment = random.choice(COMMENTARY_TEMPLATES["goal_no_assist"]).format(
                    scorer=scorer.name, team=away_team.name
                )
            all_goal_events.append(("away", comment))
    
    random.shuffle(all_goal_events)
    for _, comment in all_goal_events:
        match.commentary.append(comment)
    
    for player in home_available + away_available:
        if random.random() < 0.02:
            weeks = random.randint(1, 6)
            player.injured_weeks = weeks
            team_name = player.team
            match.injuries.append((player.name, team_name, weeks))
            match.commentary.append(
                random.choice(COMMENTARY_TEMPLATES["injury"]).format(
                    player=player.name, team=team_name, weeks=weeks
                )
            )
    
    for player in home_available + away_available:
        player.fitness = max(50, player.fitness - random.randint(3, 8))
    
    match.commentary.append(
        random.choice(COMMENTARY_TEMPLATES["match_end"]).format(
            home=home_team.name, away=away_team.name,
            home_score=home_goals, away_score=away_goals
        )
    )
    
    return match

def process_week_end(league: Dict[int, List[Team]]):
    for div_teams in league.values():
        for team in div_teams:
            for player in team.players:
                if player.injured_weeks > 0:
                    player.injured_weeks -= 1
                
                player.fitness = min(100, player.fitness + random.randint(5, 15))
                
                player.form = max(40, min(99, player.form + random.randint(-3, 3)))

def apply_season_aging(league: Dict[int, List[Team]]):
    for div_teams in league.values():
        for team in div_teams:
            for player in team.players:
                player.age += 1
                
                if player.age < 24:
                    growth = random.randint(1, 4)
                    player.rating = min(99, player.rating + growth)
                elif player.age < 28:
                    change = random.randint(-1, 2)
                    player.rating = max(40, min(99, player.rating + change))
                elif player.age < 31:
                    change = random.randint(-2, 1)
                    player.rating = max(40, min(99, player.rating + change))
                elif player.age < 34:
                    decline = random.randint(1, 3)
                    player.rating = max(40, player.rating - decline)
                else:
                    decline = random.randint(2, 5)
                    player.rating = max(40, player.rating - decline)
                
                player.market_value = player.calculate_market_value()
                
                player.form = random.randint(60, 80)
                player.fitness = random.randint(85, 100)
                player.injured_weeks = 0

def retire_old_players(league: Dict[int, List[Team]]):
    for div_teams in league.values():
        for team in div_teams:
            retired = [p for p in team.players if p.age >= 38 or (p.age >= 35 and random.random() < 0.3)]
            
            for player in retired:
                team.players.remove(player)
                new_player = Player(
                    name=generate_player_name(),
                    position=player.position,
                    rating=max(40, team.rating + random.randint(-20, -5)),
                    team=team.name,
                    age=random.randint(17, 21),
                    form=random.randint(60, 75),
                    fitness=random.randint(90, 100)
                )
                team.players.append(new_player)

def calculate_standings(teams: List[Team], fixtures: List[List[Match]]) -> pd.DataFrame:
    standings = {team.name: {
        "Team": team.name,
        "Rating": team.rating,
        "P": 0, "W": 0, "D": 0, "L": 0, "GF": 0, "GA": 0, "GD": 0, "Pts": 0
    } for team in teams}
    
    for round_matches in fixtures:
        for match in round_matches:
            if match.played:
                standings[match.home_team]["P"] += 1
                standings[match.away_team]["P"] += 1
                standings[match.home_team]["GF"] += match.home_goals
                standings[match.home_team]["GA"] += match.away_goals
                standings[match.away_team]["GF"] += match.away_goals
                standings[match.away_team]["GA"] += match.home_goals
                
                if match.home_goals > match.away_goals:
                    standings[match.home_team]["W"] += 1
                    standings[match.home_team]["Pts"] += 3
                    standings[match.away_team]["L"] += 1
                elif match.home_goals < match.away_goals:
                    standings[match.away_team]["W"] += 1
                    standings[match.away_team]["Pts"] += 3
                    standings[match.home_team]["L"] += 1
                else:
                    standings[match.home_team]["D"] += 1
                    standings[match.away_team]["D"] += 1
                    standings[match.home_team]["Pts"] += 1
                    standings[match.away_team]["Pts"] += 1
    
    for team in standings:
        standings[team]["GD"] = standings[team]["GF"] - standings[team]["GA"]
    
    df = pd.DataFrame(list(standings.values()))
    df = df.sort_values(by=["Pts", "GD", "GF"], ascending=[False, False, False]).reset_index(drop=True)
    df.index = df.index + 1
    df.index.name = "Pos"
    
    return df

def get_top_scorers(league: Dict[int, List[Team]], limit: int = 20) -> pd.DataFrame:
    all_players = []
    for division, teams in league.items():
        for team in teams:
            for player in team.players:
                if player.goals > 0:
                    all_players.append({
                        "Player": player.name,
                        "Team": player.team,
                        "Position": player.position,
                        "Age": player.age,
                        "Rating": player.rating,
                        "Goals": player.goals,
                        "Division": DIVISION_NAMES[division]
                    })
    
    df = pd.DataFrame(all_players)
    if df.empty:
        return pd.DataFrame(columns=["Player", "Team", "Position", "Age", "Rating", "Goals", "Division"])
    
    df = df.sort_values(by="Goals", ascending=False).head(limit).reset_index(drop=True)
    df.index = df.index + 1
    df.index.name = "Rank"
    return df

def get_top_assisters(league: Dict[int, List[Team]], limit: int = 20) -> pd.DataFrame:
    all_players = []
    for division, teams in league.items():
        for team in teams:
            for player in team.players:
                if player.assists > 0:
                    all_players.append({
                        "Player": player.name,
                        "Team": player.team,
                        "Position": player.position,
                        "Age": player.age,
                        "Rating": player.rating,
                        "Assists": player.assists,
                        "Division": DIVISION_NAMES[division]
                    })
    
    df = pd.DataFrame(all_players)
    if df.empty:
        return pd.DataFrame(columns=["Player", "Team", "Position", "Age", "Rating", "Assists", "Division"])
    
    df = df.sort_values(by="Assists", ascending=False).head(limit).reset_index(drop=True)
    df.index = df.index + 1
    df.index.name = "Rank"
    return df

def apply_promotion_relegation(league: Dict[int, List[Team]], all_fixtures: Dict[int, List[List[Match]]]) -> Tuple[Dict[int, List[Team]], Dict[int, List[str]], Dict[int, List[str]]]:
    standings_by_div = {}
    for div in range(1, 5):
        standings_by_div[div] = calculate_standings(league[div], all_fixtures[div])
    
    promotions = {}
    relegations = {}
    
    for div in range(1, 4):
        current_standings = standings_by_div[div]
        lower_standings = standings_by_div[div + 1]
        
        relegated_teams = current_standings.tail(2)["Team"].tolist()
        promoted_teams = lower_standings.head(2)["Team"].tolist()
        
        relegations[div] = relegated_teams
        promotions[div + 1] = promoted_teams
        
        new_upper = []
        new_lower = []
        
        for team in league[div]:
            if team.name in relegated_teams:
                team.division = div + 1
                new_lower.append(team)
            else:
                new_upper.append(team)
        
        for team in league[div + 1]:
            if team.name in promoted_teams:
                team.division = div
                new_upper.append(team)
            else:
                new_lower.append(team)
        
        league[div] = new_upper
        league[div + 1] = new_lower
    
    return league, promotions, relegations

def save_season_history(league: Dict[int, List[Team]], all_fixtures: Dict[int, List[List[Match]]], 
                        season_number: int, promotions: Dict, relegations: Dict, cup_winner: str) -> SeasonHistory:
    standings_by_div = {}
    division_winners = {}
    for div in range(1, 5):
        standings = calculate_standings(league[div], all_fixtures[div])
        standings_by_div[div] = standings
        division_winners[div] = standings.iloc[0]["Team"]
    
    top_scorers_df = get_top_scorers(league, 5)
    top_assisters_df = get_top_assisters(league, 5)
    
    history = SeasonHistory(
        season_number=season_number,
        division_winners=division_winners,
        top_scorers=top_scorers_df.to_dict('records') if not top_scorers_df.empty else [],
        top_assisters=top_assisters_df.to_dict('records') if not top_assisters_df.empty else [],
        promotions=promotions,
        relegations=relegations,
        cup_winner=cup_winner
    )
    
    return history

def generate_transfer_listings(league: Dict[int, List[Team]], num_listings: int = 15) -> List[TransferListing]:
    listings = []
    all_players = []
    
    for div_teams in league.values():
        for team in div_teams:
            for player in team.players:
                if len(team.players) > 20:
                    all_players.append((player, team))
    
    random.shuffle(all_players)
    
    for player, team in all_players[:num_listings]:
        price_variation = random.uniform(0.8, 1.3)
        asking_price = int(player.market_value * price_variation)
        
        listings.append(TransferListing(
            player_name=player.name,
            selling_team=team.name,
            asking_price=asking_price,
            player_data=player.to_dict()
        ))
    
    return listings

def execute_transfer(buyer_team: Team, seller_team: Team, player: Player, price: int) -> bool:
    if buyer_team.budget < price:
        return False
    
    if len(buyer_team.players) >= 30:
        return False
    
    seller_team.players.remove(player)
    player.team = buyer_team.name
    buyer_team.players.append(player)
    
    buyer_team.budget -= price
    seller_team.budget += price
    
    return True

def format_money(amount: int) -> str:
    if amount >= 1000000:
        return f"${amount / 1000000:.1f}M"
    elif amount >= 1000:
        return f"${amount / 1000:.0f}K"
    else:
        return f"${amount}"

def main():
    st.set_page_config(page_title="Football League Simulator", page_icon="⚽", layout="wide")
    
    st.title("⚽ Football League Simulator")
    st.markdown("Simulate a complete football league with 4 divisions, promotion/relegation, cup competition, and player management!")
    
    if "initialized" not in st.session_state:
        st.session_state.initialized = False
        st.session_state.league = None
        st.session_state.all_fixtures = None
        st.session_state.current_matchday = {1: 0, 2: 0, 3: 0, 4: 0}
        st.session_state.season_completed = False
        st.session_state.season_number = 1
        st.session_state.history = []
        st.session_state.cup_matches = []
        st.session_state.cup_round = 0
        st.session_state.cup_winner = ""
        st.session_state.transfer_listings = []
        st.session_state.last_match_commentary = []
    
    with st.sidebar:
        st.header("Controls")
        
        if st.button("🆕 New League", use_container_width=True):
            st.session_state.league = create_league()
            st.session_state.all_fixtures = {}
            for div in range(1, 5):
                st.session_state.all_fixtures[div] = generate_fixtures(st.session_state.league[div])
            st.session_state.current_matchday = {1: 0, 2: 0, 3: 0, 4: 0}
            st.session_state.season_completed = False
            st.session_state.season_number = 1
            st.session_state.initialized = True
            st.session_state.history = []
            st.session_state.cup_matches = generate_cup_draw(st.session_state.league)
            st.session_state.cup_round = 1
            st.session_state.cup_winner = ""
            st.session_state.transfer_listings = generate_transfer_listings(st.session_state.league)
            st.session_state.last_match_commentary = []
            st.rerun()
        
        if st.session_state.initialized and not st.session_state.season_completed:
            st.divider()
            
            if st.button("▶️ Simulate Next Matchday", use_container_width=True):
                team_dict = {}
                for div, teams in st.session_state.league.items():
                    for team in teams:
                        team_dict[team.name] = team
                
                all_done = True
                st.session_state.last_match_commentary = []
                
                for div in range(1, 5):
                    matchday = st.session_state.current_matchday[div]
                    if matchday < len(st.session_state.all_fixtures[div]):
                        all_done = False
                        for match in st.session_state.all_fixtures[div][matchday]:
                            simulate_match(match, team_dict)
                            st.session_state.last_match_commentary.extend(match.commentary)
                        st.session_state.current_matchday[div] += 1
                
                process_week_end(st.session_state.league)
                
                if all_done or all(st.session_state.current_matchday[d] >= len(st.session_state.all_fixtures[d]) for d in range(1, 5)):
                    st.session_state.season_completed = True
                
                st.rerun()
            
            if st.button("⏩ Simulate Full Season", use_container_width=True):
                team_dict = {}
                for div, teams in st.session_state.league.items():
                    for team in teams:
                        team_dict[team.name] = team
                
                for div in range(1, 5):
                    while st.session_state.current_matchday[div] < len(st.session_state.all_fixtures[div]):
                        matchday = st.session_state.current_matchday[div]
                        for match in st.session_state.all_fixtures[div][matchday]:
                            simulate_match(match, team_dict)
                        st.session_state.current_matchday[div] += 1
                        process_week_end(st.session_state.league)
                
                round_names = ["Round 1", "Quarter Finals", "Semi Finals", "Final"]
                while not st.session_state.cup_winner and st.session_state.cup_matches:
                    for match in st.session_state.cup_matches:
                        if not match.played:
                            simulate_cup_match(match, team_dict)
                    
                    winners = [m.winner for m in st.session_state.cup_matches if m.played]
                    
                    if len(winners) == 1:
                        st.session_state.cup_winner = winners[0]
                        break
                    elif len(winners) >= 2:
                        random.shuffle(winners)
                        new_matches = []
                        st.session_state.cup_round += 1
                        round_name = round_names[min(st.session_state.cup_round - 1, 3)]
                        
                        for i in range(0, len(winners), 2):
                            if i + 1 < len(winners):
                                new_matches.append(CupMatch(
                                    home_team=winners[i],
                                    away_team=winners[i + 1],
                                    round_name=round_name
                                ))
                        
                        if new_matches:
                            st.session_state.cup_matches = new_matches
                        elif len(winners) == 1:
                            st.session_state.cup_winner = winners[0]
                            break
                    else:
                        break
                
                st.session_state.season_completed = True
                st.rerun()
        
        if st.session_state.initialized and st.session_state.season_completed:
            st.divider()
            st.success("Season Complete!")
            
            if st.button("🔄 Start New Season", use_container_width=True):
                standings_by_div = {}
                division_winners = {}
                for div in range(1, 5):
                    standings = calculate_standings(st.session_state.league[div], st.session_state.all_fixtures[div])
                    standings_by_div[div] = standings
                    division_winners[div] = standings.iloc[0]["Team"]
                
                top_scorers_df = get_top_scorers(st.session_state.league, 5)
                top_assisters_df = get_top_assisters(st.session_state.league, 5)
                
                league, promotions, relegations = apply_promotion_relegation(
                    st.session_state.league, 
                    st.session_state.all_fixtures
                )
                st.session_state.league = league
                
                history = SeasonHistory(
                    season_number=st.session_state.season_number,
                    division_winners=division_winners,
                    top_scorers=top_scorers_df.to_dict('records') if not top_scorers_df.empty else [],
                    top_assisters=top_assisters_df.to_dict('records') if not top_assisters_df.empty else [],
                    promotions=promotions,
                    relegations=relegations,
                    cup_winner=st.session_state.cup_winner
                )
                st.session_state.history.append(history)
                
                apply_season_aging(st.session_state.league)
                retire_old_players(st.session_state.league)
                
                for div, teams in st.session_state.league.items():
                    for team in teams:
                        for player in team.players:
                            player.goals = 0
                            player.assists = 0
                
                st.session_state.all_fixtures = {}
                for div in range(1, 5):
                    st.session_state.all_fixtures[div] = generate_fixtures(st.session_state.league[div])
                
                st.session_state.current_matchday = {1: 0, 2: 0, 3: 0, 4: 0}
                st.session_state.season_completed = False
                st.session_state.season_number += 1
                st.session_state.cup_matches = generate_cup_draw(st.session_state.league)
                st.session_state.cup_round = 1
                st.session_state.cup_winner = ""
                st.session_state.transfer_listings = generate_transfer_listings(st.session_state.league)
                st.rerun()
        
        if st.session_state.initialized:
            st.divider()
            st.info(f"**Season {st.session_state.season_number}**")
            for div in range(1, 5):
                total_matchdays = len(st.session_state.all_fixtures[div]) if st.session_state.all_fixtures else 0
                current = st.session_state.current_matchday[div]
                st.caption(f"{DIVISION_NAMES[div]}: Matchday {current}/{total_matchdays}")
    
    if not st.session_state.initialized:
        st.info("👈 Click 'New League' in the sidebar to start the simulation!")
        
        st.subheader("How it works")
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown("""
            **League Structure:**
            - 4 Divisions with 8 teams each
            - Each team plays home and away against all others
            - Top 2 promoted, bottom 2 relegated
            """)
        with col2:
            st.markdown("""
            **Player System:**
            - 22-25 players per team with ages 17-37
            - Positions: GK, DFC, MC, ST
            - Form & fitness affect performance
            - Injuries can sideline players
            """)
        with col3:
            st.markdown("""
            **Additional Features:**
            - Cup competition alongside league
            - Transfer market with player values
            - Player development & aging
            - Season history tracking
            """)
    else:
        tabs = st.tabs(["📊 Standings", "⚽ Top Scorers", "🅰️ Top Assisters", "👥 Teams & Squads", 
                       "📅 Results", "🏆 Cup", "💰 Transfers", "📜 History"])
        
        with tabs[0]:
            st.header(f"League Standings - Season {st.session_state.season_number}")
            
            for div in range(1, 5):
                with st.expander(f"🏆 {DIVISION_NAMES[div]}", expanded=(div == 1)):
                    standings = calculate_standings(
                        st.session_state.league[div], 
                        st.session_state.all_fixtures[div]
                    )
                    
                    def highlight_positions(row):
                        idx = row.name
                        if idx <= 2:
                            return ['background-color: #90EE90'] * len(row)
                        elif idx >= len(standings) - 1:
                            return ['background-color: #FFB6C1'] * len(row)
                        return [''] * len(row)
                    
                    if div < 4:
                        styled_df = standings.style.apply(highlight_positions, axis=1)
                        st.dataframe(styled_df, use_container_width=True)
                        st.caption("🟢 Promotion zone | 🔴 Relegation zone")
                    else:
                        styled_df = standings.style.apply(
                            lambda row: ['background-color: #90EE90'] * len(row) if row.name <= 2 else [''] * len(row), 
                            axis=1
                        )
                        st.dataframe(styled_df, use_container_width=True)
                        st.caption("🟢 Promotion zone")
        
        with tabs[1]:
            st.header("🏅 Top Goalscorers")
            scorers = get_top_scorers(st.session_state.league, 30)
            if not scorers.empty:
                st.dataframe(scorers, use_container_width=True)
            else:
                st.info("No goals scored yet. Simulate some matches!")
        
        with tabs[2]:
            st.header("🅰️ Top Assist Providers")
            assisters = get_top_assisters(st.session_state.league, 30)
            if not assisters.empty:
                st.dataframe(assisters, use_container_width=True)
            else:
                st.info("No assists recorded yet. Simulate some matches!")
        
        with tabs[3]:
            st.header("👥 Teams & Squads")
            
            col1, col2 = st.columns(2)
            with col1:
                selected_div = st.selectbox("Select Division", options=list(range(1, 5)), 
                                           format_func=lambda x: DIVISION_NAMES[x])
            
            teams_in_div = st.session_state.league[selected_div]
            with col2:
                selected_team = st.selectbox("Select Team", options=[t.name for t in teams_in_div])
            
            team = next(t for t in teams_in_div if t.name == selected_team)
            
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Team Rating", team.rating)
            with col2:
                st.metric("Squad Size", len(team.players))
            with col3:
                total_goals = sum(p.goals for p in team.players)
                st.metric("Team Goals", total_goals)
            with col4:
                st.metric("Budget", format_money(team.budget))
            
            available = len([p for p in team.players if p.is_available()])
            injured = len([p for p in team.players if p.injured_weeks > 0])
            
            st.caption(f"Available: {available} | Injured: {injured}")
            
            st.subheader(f"Squad - {team.name}")
            
            squad_data = []
            for player in sorted(team.players, key=lambda p: (
                {"GK": 0, "DFC": 1, "MC": 2, "ST": 3}[p.position], -p.rating
            )):
                status = "✅" if player.is_available() else f"🏥 ({player.injured_weeks}w)"
                squad_data.append({
                    "Name": player.name,
                    "Pos": player.position,
                    "Age": player.age,
                    "Rating": player.rating,
                    "Form": player.form,
                    "Fitness": player.fitness,
                    "Status": status,
                    "Goals": player.goals,
                    "Assists": player.assists,
                    "Value": format_money(player.market_value)
                })
            
            squad_df = pd.DataFrame(squad_data)
            st.dataframe(squad_df, use_container_width=True, hide_index=True)
        
        with tabs[4]:
            st.header("📅 Match Results & Commentary")
            
            result_div = st.selectbox("Select Division", options=list(range(1, 5)), 
                                     format_func=lambda x: DIVISION_NAMES[x], key="results_div")
            
            fixtures = st.session_state.all_fixtures[result_div]
            played_matches = []
            
            for matchday_idx, round_matches in enumerate(fixtures):
                for match in round_matches:
                    if match.played:
                        played_matches.append({
                            "matchday": matchday_idx + 1,
                            "match": match
                        })
            
            if played_matches:
                matchdays = sorted(set(m["matchday"] for m in played_matches), reverse=True)
                selected_matchday = st.selectbox("Select Matchday", options=matchdays)
                
                matchday_matches = [m for m in played_matches if m["matchday"] == selected_matchday]
                
                for match_info in matchday_matches:
                    match = match_info["match"]
                    with st.expander(f"{match.home_team} {match.home_goals} - {match.away_goals} {match.away_team}"):
                        st.markdown("**Match Commentary:**")
                        for comment in match.commentary:
                            st.write(f"• {comment}")
                        
                        if match.injuries:
                            st.markdown("**Injuries:**")
                            for player, team, weeks in match.injuries:
                                st.write(f"🏥 {player} ({team}) - Out for {weeks} weeks")
            else:
                st.info("No matches played yet. Simulate some matchdays!")
        
        with tabs[5]:
            st.header("🏆 Cup Competition")
            
            if st.session_state.cup_winner:
                st.success(f"🏆 Cup Winner: {st.session_state.cup_winner}")
            
            round_names = ["Round 1", "Quarter Finals", "Semi Finals", "Final"]
            current_round_name = round_names[min(st.session_state.cup_round - 1, 3)] if st.session_state.cup_round > 0 else "Not Started"
            
            st.subheader(f"Current Round: {current_round_name}")
            
            if st.session_state.cup_matches and not st.session_state.cup_winner:
                unplayed = [m for m in st.session_state.cup_matches if not m.played]
                
                if unplayed:
                    if st.button("🎲 Simulate Cup Round", use_container_width=True):
                        team_dict = {}
                        for div, teams in st.session_state.league.items():
                            for team in teams:
                                team_dict[team.name] = team
                        
                        for match in unplayed:
                            simulate_cup_match(match, team_dict)
                        
                        winners = [m.winner for m in st.session_state.cup_matches if m.played]
                        
                        if len(winners) == 1:
                            st.session_state.cup_winner = winners[0]
                        elif len(winners) >= 2:
                            random.shuffle(winners)
                            new_matches = []
                            next_round = st.session_state.cup_round + 1
                            round_name = round_names[min(next_round - 1, 3)]
                            
                            for i in range(0, len(winners), 2):
                                if i + 1 < len(winners):
                                    new_matches.append(CupMatch(
                                        home_team=winners[i],
                                        away_team=winners[i + 1],
                                        round_name=round_name
                                    ))
                            
                            if new_matches:
                                st.session_state.cup_matches = new_matches
                                st.session_state.cup_round = next_round
                            elif len(winners) == 1:
                                st.session_state.cup_winner = winners[0]
                        
                        st.rerun()
                
                st.subheader("Fixtures")
                for match in st.session_state.cup_matches:
                    if match.played:
                        result = f"{match.home_team} {match.home_goals} - {match.away_goals} {match.away_team}"
                        st.write(f"✅ {result} (Winner: {match.winner})")
                    else:
                        st.write(f"⏳ {match.home_team} vs {match.away_team}")
        
        with tabs[6]:
            st.header("💰 Transfer Market")
            
            if not st.session_state.transfer_listings:
                st.info("No players available on the transfer market.")
            else:
                st.subheader("Available Players")
                
                for i, listing in enumerate(st.session_state.transfer_listings):
                    player_data = listing.player_data
                    
                    with st.expander(f"{listing.player_name} - {listing.selling_team} - {format_money(listing.asking_price)}"):
                        col1, col2, col3, col4 = st.columns(4)
                        with col1:
                            st.metric("Position", player_data["position"])
                        with col2:
                            st.metric("Age", player_data["age"])
                        with col3:
                            st.metric("Rating", player_data["rating"])
                        with col4:
                            st.metric("Price", format_money(listing.asking_price))
                        
                        buyer_options = []
                        for div_teams in st.session_state.league.values():
                            for team in div_teams:
                                if team.name != listing.selling_team and team.budget >= listing.asking_price:
                                    buyer_options.append(team.name)
                        
                        if buyer_options:
                            buyer_name = st.selectbox(
                                "Select Buying Team",
                                options=buyer_options,
                                key=f"buyer_{i}"
                            )
                            
                            if st.button(f"Complete Transfer", key=f"transfer_{i}"):
                                buyer_team = None
                                seller_team = None
                                player = None
                                
                                for div_teams in st.session_state.league.values():
                                    for team in div_teams:
                                        if team.name == buyer_name:
                                            buyer_team = team
                                        if team.name == listing.selling_team:
                                            seller_team = team
                                            for p in team.players:
                                                if p.name == listing.player_name:
                                                    player = p
                                                    break
                                
                                if buyer_team and seller_team and player:
                                    success = execute_transfer(buyer_team, seller_team, player, listing.asking_price)
                                    if success:
                                        st.session_state.transfer_listings.remove(listing)
                                        st.success(f"{listing.player_name} transferred to {buyer_name}!")
                                        st.rerun()
                                    else:
                                        st.error("Transfer failed!")
                        else:
                            st.warning("No teams can afford this player or have squad space.")
        
        with tabs[7]:
            st.header("📜 Season History")
            
            if not st.session_state.history:
                st.info("No completed seasons yet. Finish a season to see history!")
            else:
                for history in reversed(st.session_state.history):
                    with st.expander(f"Season {history.season_number}", expanded=(history == st.session_state.history[-1])):
                        st.subheader("Division Winners")
                        for div, winner in history.division_winners.items():
                            st.write(f"🏆 {DIVISION_NAMES[div]}: **{winner}**")
                        
                        if history.cup_winner:
                            st.write(f"🏆 Cup Winner: **{history.cup_winner}**")
                        
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.subheader("Top Scorers")
                            if history.top_scorers:
                                for scorer in history.top_scorers[:5]:
                                    st.write(f"⚽ {scorer['Player']} ({scorer['Team']}) - {scorer['Goals']} goals")
                        
                        with col2:
                            st.subheader("Top Assisters")
                            if history.top_assisters:
                                for assister in history.top_assisters[:5]:
                                    st.write(f"🅰️ {assister['Player']} ({assister['Team']}) - {assister['Assists']} assists")
                        
                        st.subheader("Promotions & Relegations")
                        for div in range(2, 5):
                            if div in history.promotions and history.promotions[div]:
                                st.write(f"⬆️ Promoted to {DIVISION_NAMES[div-1]}: {', '.join(history.promotions[div])}")
                        for div in range(1, 4):
                            if div in history.relegations and history.relegations[div]:
                                st.write(f"⬇️ Relegated from {DIVISION_NAMES[div]}: {', '.join(history.relegations[div])}")

if __name__ == "__main__":
    main()
