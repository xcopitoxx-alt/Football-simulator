# Replit.md

## Overview

This is a comprehensive football/soccer management simulation application built with Python and Streamlit. The application simulates football leagues with 4 divisions, player management, team structures, match statistics, cup competitions, transfer market, and multi-season progression with promotion/relegation.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Framework
- **Streamlit**: Used for building the interactive web interface
- Runs on port 5000
- 8 main tabs: Standings, Top Scorers, Top Assisters, Teams & Squads, Results, Cup, Transfers, History

### Data Modeling
- **Dataclass-based entities**: Player, Team, Match, CupMatch, SeasonHistory, TransferListing
- All entities have `to_dict()` and `from_dict()` methods for serialization
- Lightweight in-memory simulation without database persistence

### Game Structure
- **Division hierarchy**: 4 divisions with 8 teams each (32 teams total)
- **Position-based roster**: Teams have 22-25 players with positions (GK, DFC, MC, ST)
- **Rating system**: Teams rated 60-99, players rated 40-99
- **Player attributes**: Age (17-37), form (40-99), fitness (50-100), injured_weeks

### Key Features

#### League System
- Full double round-robin season (home and away matches)
- Top 2 teams promoted, bottom 2 relegated between divisions
- Standings with points, wins, draws, losses, goal difference

#### Player System
- Age-based development: Young players (< 24) grow, veterans (> 30) decline
- Form and fitness affect match performance via `get_effective_rating()`
- Injuries can sideline players for 1-6 weeks
- Market value calculated based on rating and age

#### Match Simulation
- Rating-weighted goal expectations with Gaussian distribution
- Goal scorers and assisters selected by player rating weights
- Detailed play-by-play commentary for each match
- Injury chance during matches (2% per player)

#### Cup Competition
- Single-elimination tournament with all 32 teams
- Rounds: Round 1 → Quarter Finals → Semi Finals → Final
- Simulated alongside league season

#### Transfer Market
- Players listed with asking prices based on market value
- Teams can buy players from other teams
- Budget management for each team

#### Season History
- Tracks division winners, cup winner, top scorers/assisters
- Records promotions and relegations
- Accessible across multiple seasons

### State Management
- Application state managed through Streamlit's `session_state`
- Key state variables: league, all_fixtures, current_matchday, season_number, cup_matches, transfer_listings, history

## External Dependencies

### Python Libraries
- **Streamlit**: Web application framework
- **Pandas**: Data manipulation and display of tabular information
- **Python standard library**: dataclasses, typing, random

### No External Services
- Operates as a standalone simulation
- All data is generated and managed in-memory during runtime
- No database or authentication required
